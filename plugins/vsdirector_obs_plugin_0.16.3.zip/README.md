# VS Director OBS source

This OBS input consumes the `VSDirector.Live` shared-memory protocol published
by VS Director. It outputs bottom-up BGRA video as an asynchronous source and
48 kHz interleaved stereo PCM as source audio.


例如 OBS 位于 D:\obs-studio，解压后应存在：

D:\obs-studio\obs-plugins\64bit\vsdirector-obs.dll
D:\obs-studio\data\obs-plugins\vsdirector-obs\locale\zh-CN.ini

安装后完全重启 OBS。在 OBS 日志中应看到：

[VS Director] Offscreen video/audio source loaded
